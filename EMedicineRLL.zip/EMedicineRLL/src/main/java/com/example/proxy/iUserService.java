package com.example.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.domain.User;
import com.example.fallback.UserService;


@FeignClient(name="userService",fallback=UserService.class)
public interface iUserService {
	
	@GetMapping(value="/byEmail/{email}" ,produces = {MediaType.APPLICATION_JSON_VALUE})
	User findByEmail(String email);
	
	@PostMapping(value="/saveuser" ,produces = {MediaType.APPLICATION_JSON_VALUE} ,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	void saveUser(User user);
	
	@GetMapping(value="/users" ,produces={MediaType.APPLICATION_JSON_VALUE})
	List<User> findAll();
	
	@DeleteMapping(value="/deletebyid/{id}")
	void deletebyid(int id);
}
